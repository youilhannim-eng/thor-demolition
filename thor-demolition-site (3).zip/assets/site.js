/* 토르철거 공통 스크립트: 모바일 메뉴, 블로그 옛 주소 이동, 게시판 검색, 견적문의 폼(Web3Forms) */
(function () {
  // 아임웹 시절 블로그 글 주소(/blog/?...&idx=번호) → 새 글 주소
  var BLOG_MAP = {"173144014": "/blog/closure-subsidy-schedule", "173143968": "/blog/lease-end-restoration", "173143041": "/blog/restoration-8-steps", "173143019": "/blog/regional-demolition-guide", "173142994": "/blog/closure-subsidy-checklist", "173142755": "/blog/restoration-cost"};
  if (/^\/blog\/?$/.test(location.pathname)) {
    var m = location.search.match(/[?&]idx=(\d+)/);
    if (m && BLOG_MAP[m[1]]) { location.replace(BLOG_MAP[m[1]]); return; }
  }

  // 모바일 메뉴
  var ham = document.querySelector('.thd-ham');
  var drawer = document.getElementById('thd-drawer');
  function setOpen(open) {
    if (!drawer) return;
    drawer.hidden = !open;
    if (ham) ham.setAttribute('aria-expanded', open ? 'true' : 'false');
    document.documentElement.style.overflow = open ? 'hidden' : '';
  }
  if (ham) ham.addEventListener('click', function () { setOpen(true); });
  if (drawer) drawer.addEventListener('click', function (e) {
    if (e.target.closest('[data-close]')) setOpen(false);
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });

  // 게시판 검색
  var q = document.querySelector('[data-board-search]');
  if (q) q.addEventListener('input', function () {
    var v = q.value.trim().toLowerCase(), shown = 0;
    document.querySelectorAll('.bcard').forEach(function (c) {
      var ok = !v || c.textContent.toLowerCase().indexOf(v) !== -1;
      c.style.display = ok ? '' : 'none'; if (ok) shown++;
    });
    var empty = document.querySelector('.bboard-empty'); if (empty) empty.hidden = shown !== 0;
  });

  // 견적문의 폼
  var form = document.getElementById('tform');
  if (form) {
    var msg = form.querySelector('.tform-msg');
    var tels = form.querySelectorAll('.tform-tel input');
    tels.forEach(function (t, i) {
      t.addEventListener('input', function () {
        t.value = t.value.replace(/\D/g, '');
        if (t.value.length >= t.maxLength && tels[i + 1]) tels[i + 1].focus();
      });
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      msg.className = 'tform-msg';
      var name = form.querySelector('[name="성함"]').value.trim();
      var phone = [tels[0].value, tels[1].value, tels[2].value];
      if (!name) { msg.textContent = '성함을 입력해 주세요.'; msg.className = 'tform-msg err'; return; }
      if (phone[0].length < 2 || phone[1].length < 3 || phone[2].length < 4) { msg.textContent = '연락처를 정확히 입력해 주세요.'; msg.className = 'tform-msg err'; return; }
      form.querySelector('[name="연락처"]').value = phone.join('-');
      var key = form.querySelector('[name="access_key"]').value;
      if (!key) { msg.textContent = '온라인 문의 준비 중입니다. 전화(010-2225-6775)로 연락 주세요.'; msg.className = 'tform-msg err'; return; }
      var btn = form.querySelector('button[type=submit]');
      btn.disabled = true; msg.textContent = '보내는 중입니다…';
      fetch(form.action, { method: 'POST', headers: { Accept: 'application/json' }, body: new FormData(form) })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d && d.success) {
            form.reset();
            msg.textContent = '문의가 접수되었습니다. 확인 후 연락드리겠습니다.';
          } else { throw new Error((d && d.message) || 'fail'); }
        })
        .catch(function () { msg.textContent = '전송에 실패했습니다. 전화(010-2225-6775)로 연락 주세요.'; msg.className = 'tform-msg err'; })
        .then(function () { btn.disabled = false; });
    });
  }
})();
